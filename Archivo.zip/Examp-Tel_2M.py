
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  2 12:04:14 2020

@author: joelherreravazquez
"""

import Kraken as kn
import numpy as np
import matplotlib.pyplot as plt
import time
 
#_________________________________________________________________#    
P_Obj=kn.surf()
P_Obj.Rc=0
P_Obj.Thickness=1000+3.452200000000000E+003
P_Obj.Glass="AIR"
P_Obj.Diameter=1.059E+003*2.0
#_________________________________________________________________#
Thickness=3.452200000000000E+003
M1=kn.surf()
M1.Rc=-9.638000000004009E+003
M1.Thickness=-Thickness
M1.k=-1.077310000000000E+000
M1.Glass="MIRROR"
M1.Diameter=1.059E+003*2.0
M1.InDiameter=250*2.0
#_________________________________________________________________#
M2=kn.surf()
M2.Rc=-3.93E+003
M2.Thickness=Thickness+1.037525880125084E+003
M2.k=-4.328100000000000E+000
M2.Glass="MIRROR"
M2.Diameter=3.365E+002*2.0
M2.AxisMove=0
#_________________________________________________________________#
P_Ima=kn.surf()
P_Ima.Diameter=1000.0
P_Ima.Glass="AIR"
P_Ima.Name="Plano imagen"
A=[P_Obj,M1,M2,P_Ima]
#_________________________________________________________________#
configuracion_1=kn.Kraken_setup()
Telescopio=kn.system(A,configuracion_1)
Rayos=kn.raykeeper(Telescopio)
#_________________________________________________________________#
W = 0.4
sup = 1
AperVal = 2010
AperType = "EPD" # "STOP"
Pup = kn.pupilcalc(Telescopio, sup, W, AperType, AperVal)
Pup.Samp=7 
Pup.FieldType = "angle"

Pup.FieldX=0.0
Pup.Ptype = "hexapolar"
xa,ya,za,La,Ma,Na=Pup.Pattern2Field()

Pup.FieldX = 0.5
Pup.FieldY = 0.5
Pup.Ptype = "square"
xb,yb,zb,Lb,Mb,Nb=Pup.Pattern2Field()

Pup.FieldX = -.5
Pup.FieldY = -.5
Pup.Ptype = "rand"
xc,yc,zc,Lc,Mc,Nc=Pup.Pattern2Field()

############################################    


for i in range(0,len(xa)):
    pSource_0 = [xa[i], ya[i], za[i]]
    dCos=[La[i], Ma[i], Na[i]]
    Telescopio.Trace(pSource_0, dCos, W)
    Rayos.push()

for i in range(0,len(xb)):
    pSource_0 = [xb[i], yb[i], zb[i]]
    dCos=[Lb[i], Mb[i], Nb[i]]
    Telescopio.Trace(pSource_0, dCos, W)
    Rayos.push()

for i in range(0,len(xc)):
    pSource_0 = [xc[i], yc[i], zc[i]]
    dCos=[Lc[i], Mc[i], Nc[i]]
    Telescopio.Trace(pSource_0, dCos, W)
    Rayos.push()
  
    
############################################        
        
kn.display3d(Telescopio,Rayos,2)



X,Y,Z,L,M,N=Rayos.pick(-1)

plt.plot(X,Y, 'x')



# axis labeling
plt.xlabel('x')
plt.ylabel('y')

# figure name
plt.title('Spot Diagram')
plt.axis('square')
plt.show()        